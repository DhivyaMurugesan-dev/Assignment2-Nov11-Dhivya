package com.example.assignment2_nov11_dhivya;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class RestockActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_restock);
    }
}
